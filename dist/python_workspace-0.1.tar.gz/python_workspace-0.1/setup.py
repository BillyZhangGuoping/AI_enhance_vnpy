from setuptools import setup, find_packages

setup(
    name="python_workspace",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        # 添加依赖项（如果有）
    ],
    description="A Python library for the workspace.",
    author="Your Name",
    author_email="your.email@example.com",
)